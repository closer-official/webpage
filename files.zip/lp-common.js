/**
 * lp-common.js — 全ページ共通処理
 * - sessionStorageからsalonデータ取得
 * - ナビゲーション描画
 * - IntersectionObserver によるrevealアニメーション
 * - フッター描画
 */

export function loadSalon() {
  const raw = sessionStorage.getItem('salonLP');
  if (!raw) return null;
  try { return JSON.parse(raw); } catch { return null; }
}

export function esc(str) {
  if (!str && str !== 0) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ── ナビ描画 ──
const PAGES = [
  { href: 'lp-top.html',        label: 'Top' },
  { href: 'lp-coupon.html',     label: 'Coupon' },
  { href: 'lp-staff.html',      label: 'Staff' },
  { href: 'lp-atmosphere.html', label: 'Atmosphere' },
  { href: 'lp-access.html',     label: 'Access' },
];

export function buildNav(salon, currentPage) {
  const nav = document.createElement('nav');
  nav.className = 'lp-nav';

  const currentFile = currentPage || location.pathname.split('/').pop();

  const links = PAGES.map(p => {
    const active = currentFile === p.href ? ' class="active"' : '';
    return `<li><a href="${p.href}"${active}>${p.label}</a></li>`;
  }).join('');

  nav.innerHTML = `
    <div class="nav-logo">${esc(salon?.name || 'Salon')}</div>
    <ul class="nav-links">${links}</ul>
    <a href="lp-top.html#reserve" class="nav-reserve">予約する</a>
    <button class="nav-hamburger" aria-label="メニュー" id="nav-hamburger">
      <span></span><span></span><span></span>
    </button>
  `;

  document.body.prepend(nav);

  // Drawer
  const drawer = document.createElement('div');
  drawer.className = 'nav-drawer';
  drawer.id = 'nav-drawer';
  drawer.innerHTML = PAGES.map(p =>
    `<a href="${p.href}">${p.label}</a>`
  ).join('') + `<a href="lp-top.html#reserve" style="color:var(--amber)">予約する</a>`;
  document.body.appendChild(drawer);

  document.getElementById('nav-hamburger').addEventListener('click', () => {
    drawer.classList.toggle('open');
  });

  drawer.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => drawer.classList.remove('open'));
  });
}

// ── フッター描画 ──
export function buildFooter(salon) {
  const footer = document.createElement('footer');
  footer.className = 'lp-footer';
  footer.innerHTML = `
    <div class="footer-inner">
      <div>
        <div class="footer-name">${esc(salon?.name || '')}</div>
        <div class="footer-address">
          ${salon?.address ? esc(salon.address) : ''}
          ${salon?.openingHours ? `<br>${esc(salon.openingHours)}` : ''}
        </div>
      </div>
      <div class="footer-copy">
        ${salon?.homepageUrl ? `<a class="footer-hp-link" href="${esc(salon.homepageUrl)}" target="_blank" rel="noopener">${esc(salon.homepageUrl)}</a>` : ''}
      </div>
    </div>
  `;
  document.body.appendChild(footer);
}

// ── CTA Strip描画 ──
export function buildCTAStrip(salon) {
  const strip = document.createElement('div');
  strip.className = 'cta-strip';
  strip.innerHTML = `
    <div class="cta-strip-inner">
      <div class="cta-strip-text">
        <span>Reserve</span>
        ${esc(salon?.name || '')}へのご予約はこちら
      </div>
      <a href="lp-top.html#reserve" class="btn-cta-dark">今すぐ予約する →</a>
    </div>
  `;
  return strip;
}

// ── Reveal animation ──
export function initReveal() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.06 });

  document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
}

// ── 空状態表示（データなし時） ──
export function showEmpty(message = 'サロンデータが見つかりません') {
  document.body.innerHTML = `
    <div class="lp-empty-state" style="min-height:100vh; background:var(--bg);">
      <p>${esc(message)}</p>
      <a href="index.html" style="font-family:var(--font-mono);font-size:0.75rem;color:var(--amber);letter-spacing:0.1em;">← 管理画面へ戻る</a>
    </div>
  `;
}

// ── ページタイトル設定 ──
export function setPageTitle(salon, suffix) {
  const base = salon?.name || 'サロン';
  document.title = suffix ? `${suffix} | ${base}` : base;
}
