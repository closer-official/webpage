/**
 * exporter.js
 * salonデータを受け取り、5ページ分のスタンドアロンHTMLを生成してZIPダウンロードする。
 * 外部依存: JSZip (CDN)
 */

// ============================================================
// 共通CSS (インライン用)
// ============================================================
const COMMON_CSS = `
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400;1,700&family=Zen+Kaku+Gothic+New:wght@300;400;500;700&family=Space+Mono:ital,wght@0,400;0,700;1,400&display=swap');
:root{--bg:#0D0D0D;--bg-2:#141414;--bg-3:#1A1A1A;--bg-4:#222222;--surface:#1E1E1E;--border:rgba(255,255,255,0.07);--border-hi:rgba(255,255,255,0.14);--white:#F2F0EC;--white-60:rgba(242,240,236,0.6);--white-30:rgba(242,240,236,0.3);--white-10:rgba(242,240,236,0.07);--amber:#E8B84B;--amber-d:#C49A2E;--amber-hi:#F5CC6A;--font-disp:'Playfair Display','Hiragino Mincho ProN',serif;--font-body:'Zen Kaku Gothic New','Hiragino Sans',sans-serif;--font-mono:'Space Mono','Courier New',monospace;--ease-out:cubic-bezier(0.16,1,0.3,1);--dur:0.45s;--nav-h:64px;--max-w:1080px;--max-w-sm:720px}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{font-size:16px;scroll-behavior:smooth}
body{font-family:var(--font-body);background:var(--bg);color:var(--white);line-height:1.75;-webkit-font-smoothing:antialiased;overflow-x:hidden}
img{max-width:100%;display:block}
a{color:var(--amber);text-decoration:none;transition:color .2s}
a:hover{color:var(--amber-hi)}
button{cursor:pointer;border:none;background:none;font-family:inherit}
body::before{content:'';position:fixed;inset:0;z-index:9999;pointer-events:none;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='1'/%3E%3C/svg%3E");background-size:120px;opacity:.028;mix-blend-mode:overlay}
.lp-nav{position:fixed;top:0;left:0;right:0;z-index:500;height:var(--nav-h);display:flex;align-items:center;padding:0 40px;background:rgba(13,13,13,0.85);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);border-bottom:1px solid var(--border)}
.nav-logo{font-family:var(--font-disp);font-size:1.1rem;font-weight:700;color:var(--white);letter-spacing:.04em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:240px;margin-right:auto}
.nav-links{display:flex;list-style:none;gap:32px;margin:0 32px}
.nav-links a{font-family:var(--font-mono);font-size:.65rem;letter-spacing:.16em;text-transform:uppercase;color:var(--white-60);transition:color .2s;position:relative;padding-bottom:2px}
.nav-links a::after{content:'';position:absolute;bottom:-4px;left:0;right:100%;height:1px;background:var(--amber);transition:right .3s var(--ease-out)}
.nav-links a:hover,.nav-links a.active{color:var(--white)}
.nav-links a:hover::after,.nav-links a.active::after{right:0}
.nav-reserve{display:inline-flex;align-items:center;gap:8px;padding:9px 22px;background:var(--amber);color:var(--bg);border-radius:2px;font-family:var(--font-mono);font-size:.65rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;transition:background .2s,transform .2s;white-space:nowrap}
.nav-reserve:hover{background:var(--amber-hi);color:var(--bg);transform:translateY(-1px)}
.nav-hamburger{display:none;flex-direction:column;gap:5px;padding:8px;margin-left:12px}
.nav-hamburger span{display:block;width:22px;height:1.5px;background:var(--white);transition:transform .3s,opacity .3s}
.nav-drawer{display:none;position:fixed;inset:var(--nav-h) 0 0 0;background:rgba(13,13,13,0.98);backdrop-filter:blur(20px);z-index:499;flex-direction:column;align-items:center;justify-content:center;gap:36px;opacity:0;pointer-events:none;transition:opacity .3s}
.nav-drawer.open{display:flex;opacity:1;pointer-events:auto}
.nav-drawer a{font-family:var(--font-disp);font-size:2rem;font-weight:400;color:var(--white-60);letter-spacing:.06em;transition:color .2s}
.nav-drawer a:hover{color:var(--amber)}
.lp-page{padding-top:var(--nav-h);min-height:100vh}
.lp-section{padding:120px 40px;max-width:var(--max-w);margin:0 auto;position:relative}
.lp-section-full{padding:120px 40px;position:relative}
.section-eyebrow{display:flex;align-items:center;gap:16px;margin-bottom:16px}
.section-tag{font-family:var(--font-mono);font-size:.62rem;letter-spacing:.22em;text-transform:uppercase;color:var(--amber)}
.section-line{flex:1;max-width:60px;height:1px;background:linear-gradient(90deg,var(--amber),transparent)}
.section-title{font-family:var(--font-disp);font-size:clamp(2rem,5vw,3.6rem);font-weight:700;letter-spacing:-.01em;line-height:1.15;color:var(--white);margin-bottom:24px}
.section-title em{font-style:italic;color:var(--amber)}
.section-lead{font-size:.95rem;color:var(--white-60);line-height:1.9;max-width:560px}
.lp-divider{width:100%;height:1px;background:var(--border);margin:0;border:none}
.reveal{opacity:0;transform:translateY(28px);transition:opacity .7s var(--ease-out),transform .7s var(--ease-out)}
.reveal.visible{opacity:1;transform:none}
.reveal-delay-1{transition-delay:.08s}.reveal-delay-2{transition-delay:.16s}.reveal-delay-3{transition-delay:.24s}.reveal-delay-4{transition-delay:.32s}
.hero{min-height:calc(100vh - var(--nav-h));display:grid;grid-template-columns:1fr 1fr;align-items:center;gap:80px;padding:80px 40px;max-width:var(--max-w);margin:0 auto}
.hero-badge{display:inline-flex;align-items:center;gap:10px;padding:6px 14px;border:1px solid rgba(232,184,75,.3);border-radius:1px;font-family:var(--font-mono);font-size:.62rem;letter-spacing:.18em;text-transform:uppercase;color:var(--amber);margin-bottom:28px;background:rgba(232,184,75,.05)}
.hero-badge::before{content:'';width:6px;height:6px;background:var(--amber);border-radius:50%;animation:pulse 2s ease-in-out infinite}
@keyframes pulse{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.4;transform:scale(.7)}}
.hero-name{font-family:var(--font-disp);font-size:clamp(2.8rem,6vw,5rem);font-weight:900;line-height:1.05;letter-spacing:-.02em;color:var(--white);margin-bottom:20px}
.hero-title{font-size:.88rem;color:var(--white-60);line-height:1.8;font-weight:300;margin-bottom:36px;max-width:440px}
.hero-rating-row{display:flex;align-items:baseline;gap:12px;margin-bottom:36px}
.hero-score{font-family:var(--font-disp);font-size:3rem;font-weight:700;color:var(--amber);line-height:1}
.hero-stars{display:flex;gap:3px}
.hero-star{color:var(--amber);font-size:1rem}
.hero-review-count{font-family:var(--font-mono);font-size:.68rem;color:var(--white-30);letter-spacing:.08em}
.hero-actions{display:flex;gap:12px;flex-wrap:wrap}
.hero-card{background:var(--surface);border:1px solid var(--border-hi);border-radius:4px;padding:32px;position:relative;overflow:hidden}
.hero-card::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,var(--amber),transparent)}
.hero-card-catch{font-family:var(--font-disp);font-size:1.1rem;font-style:italic;color:var(--white);line-height:1.7;margin-bottom:24px}
.hero-access{display:flex;align-items:flex-start;gap:10px;font-size:.82rem;color:var(--white-60);line-height:1.6;padding-top:20px;border-top:1px solid var(--border)}
.hero-access-icon{color:var(--amber);font-size:.9rem;flex-shrink:0;margin-top:2px}
.hero-deco-num{position:absolute;right:-20px;bottom:-20px;font-family:var(--font-disp);font-size:8rem;font-weight:900;color:rgba(255,255,255,.02);line-height:1;pointer-events:none;user-select:none}
.intro-grid{display:grid;grid-template-columns:1fr 1fr;gap:80px;align-items:start}
.intro-text{font-size:.9rem;color:var(--white-60);line-height:2;white-space:pre-line}
.intro-stats{display:flex;flex-direction:column;gap:1px;background:var(--border)}
.intro-stat-row{display:flex;align-items:center;justify-content:space-between;padding:20px 24px;background:var(--bg-2);gap:16px}
.intro-stat-label{font-family:var(--font-mono);font-size:.65rem;letter-spacing:.12em;text-transform:uppercase;color:var(--white-30)}
.intro-stat-value{font-family:var(--font-disp);font-size:1.1rem;font-weight:700;color:var(--white);text-align:right}
.features-list{display:flex;flex-direction:column;gap:1px;background:var(--border)}
.feature-item{display:grid;grid-template-columns:80px 1fr;background:var(--bg-2);transition:background .2s}
.feature-item:hover{background:var(--bg-3)}
.feature-num-col{padding:40px 24px;display:flex;align-items:flex-start;justify-content:center;border-right:1px solid var(--border)}
.feature-num{font-family:var(--font-mono);font-size:.6rem;letter-spacing:.16em;color:var(--amber)}
.feature-content-col{padding:36px 40px}
.feature-title{font-family:var(--font-disp);font-size:1.3rem;font-weight:700;color:var(--white);margin-bottom:12px;line-height:1.4}
.feature-text{font-size:.86rem;color:var(--white-60);line-height:1.85}
.coupon-filters{display:flex;gap:8px;margin-bottom:48px;flex-wrap:wrap}
.filter-btn{padding:8px 20px;border:1px solid var(--border-hi);border-radius:1px;font-family:var(--font-mono);font-size:.62rem;letter-spacing:.14em;text-transform:uppercase;color:var(--white-60);transition:all .2s;background:transparent;cursor:pointer}
.filter-btn:hover,.filter-btn.active{border-color:var(--amber);color:var(--amber);background:rgba(232,184,75,.06)}
.coupons-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:1px;background:var(--border)}
.coupon-card{background:var(--bg-2);padding:36px 32px;position:relative;overflow:hidden;transition:background .25s}
.coupon-card[data-hidden="true"]{display:none}
.coupon-card:hover{background:var(--bg-3)}
.coupon-card::after{content:'';position:absolute;top:0;left:0;width:3px;height:100%}
.coupon-card[data-type="新規"]::after{background:var(--amber)}
.coupon-card[data-type="再来"]::after{background:#6B9E6B}
.coupon-card[data-type="全員"]::after{background:#6B8FAE}
.coupon-type-badge{display:inline-block;padding:3px 10px;border-radius:1px;font-family:var(--font-mono);font-size:.58rem;letter-spacing:.18em;text-transform:uppercase;margin-bottom:20px}
.coupon-card[data-type="新規"] .coupon-type-badge{background:rgba(232,184,75,.12);color:var(--amber)}
.coupon-card[data-type="再来"] .coupon-type-badge{background:rgba(107,158,107,.12);color:#8BC88B}
.coupon-card[data-type="全員"] .coupon-type-badge{background:rgba(107,143,174,.12);color:#8BAEC8}
.coupon-cats{font-family:var(--font-mono);font-size:.62rem;letter-spacing:.1em;color:var(--white-30);margin-bottom:10px}
.coupon-price{font-family:var(--font-disp);font-size:3rem;font-weight:700;line-height:1;color:var(--white);margin-bottom:16px;letter-spacing:-.02em}
.coupon-price span{font-size:1.1rem;font-weight:400;color:var(--white-60);margin-right:4px}
.coupon-title{font-size:.85rem;color:var(--white-60);line-height:1.6}
.staff-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:1px;background:var(--border)}
.staff-card{background:var(--bg-2);padding:48px 36px;position:relative;overflow:hidden;transition:background .25s}
.staff-card:hover{background:var(--bg-3)}
.staff-card::before{content:attr(data-index);position:absolute;right:24px;top:24px;font-family:var(--font-mono);font-size:.6rem;letter-spacing:.2em;color:var(--white-10)}
.staff-avatar{width:72px;height:72px;border-radius:50%;background:linear-gradient(135deg,var(--bg-4),var(--surface));border:1px solid var(--border-hi);display:flex;align-items:center;justify-content:center;font-family:var(--font-disp);font-size:1.6rem;font-weight:700;color:var(--amber);margin-bottom:24px;position:relative}
.staff-avatar::after{content:'';position:absolute;inset:-3px;border-radius:50%;border:1px solid rgba(232,184,75,.2)}
.staff-name{font-family:var(--font-disp);font-size:1.5rem;font-weight:700;color:var(--white);margin-bottom:6px;line-height:1.2}
.staff-exp{display:inline-block;font-family:var(--font-mono);font-size:.6rem;letter-spacing:.12em;color:var(--amber);background:rgba(232,184,75,.08);padding:3px 10px;border-radius:1px;margin-bottom:16px}
.staff-specialty{font-size:.8rem;color:var(--white-60);line-height:1.6;margin-bottom:16px}
.staff-catch{font-size:.82rem;color:var(--white-30);line-height:1.65;padding-top:16px;border-top:1px solid var(--border)}
.atmosphere-grid{display:grid;grid-template-columns:1fr 1fr;gap:1px;background:var(--border);margin-bottom:1px}
.atmo-card{background:var(--bg-2);padding:60px 48px;position:relative;overflow:hidden;min-height:260px;display:flex;flex-direction:column;justify-content:flex-end;transition:background .3s}
.atmo-card:hover{background:var(--bg-3)}
.atmo-card:first-child{grid-column:1/-1;min-height:320px}
.atmo-index{font-family:var(--font-mono);font-size:.6rem;letter-spacing:.2em;color:var(--amber);margin-bottom:16px}
.atmo-text{font-family:var(--font-disp);font-size:1.3rem;font-weight:400;color:var(--white);line-height:1.5}
.atmo-deco{position:absolute;top:32px;right:32px;width:100px;height:100px;border-radius:50%;border:1px solid rgba(255,255,255,.03);pointer-events:none}
.message-block{background:var(--bg-2);border:1px solid var(--border);padding:64px 56px;position:relative;overflow:hidden;max-width:var(--max-w-sm);margin:80px auto 0}
.message-block::before{content:'\201C';position:absolute;top:24px;left:40px;font-family:var(--font-disp);font-size:6rem;line-height:1;color:rgba(232,184,75,.08);pointer-events:none}
.message-text{font-family:var(--font-disp);font-size:clamp(1rem,2vw,1.25rem);font-style:italic;font-weight:400;color:var(--white-60);line-height:1.9;position:relative;z-index:1}
.message-author{margin-top:28px;font-family:var(--font-mono);font-size:.65rem;letter-spacing:.14em;color:var(--amber)}
.access-layout{display:grid;grid-template-columns:1fr 1fr;gap:80px;align-items:start}
.access-address-block{margin-bottom:40px}
.access-address-label{font-family:var(--font-mono);font-size:.6rem;letter-spacing:.18em;text-transform:uppercase;color:var(--amber);margin-bottom:10px}
.access-address-text{font-family:var(--font-disp);font-size:1.2rem;font-weight:400;color:var(--white);line-height:1.5}
.access-route{background:var(--bg-2);border:1px solid var(--border);padding:28px 32px;border-radius:2px;font-size:.85rem;color:var(--white-60);line-height:1.9;white-space:pre-line}
.access-table-wrap{display:flex;flex-direction:column;gap:1px;background:var(--border)}
.access-row{display:grid;grid-template-columns:120px 1fr;background:var(--bg-2);transition:background .2s}
.access-row:hover{background:var(--bg-3)}
.access-row-key{padding:20px;font-family:var(--font-mono);font-size:.62rem;letter-spacing:.12em;text-transform:uppercase;color:var(--white-30);border-right:1px solid var(--border);display:flex;align-items:flex-start;padding-top:22px}
.access-row-val{padding:20px 24px;font-size:.86rem;color:var(--white-60);line-height:1.7}
.access-homepage{margin-top:32px}
.access-homepage a{font-family:var(--font-mono);font-size:.75rem;color:var(--amber);letter-spacing:.06em;word-break:break-all;display:flex;align-items:center;gap:8px}
.access-homepage a::before{content:'→';font-size:.9rem}
.stats-row{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:1px;background:var(--border);margin-top:80px}
.stat-box{background:var(--bg-2);padding:36px 32px}
.stat-box-label{font-family:var(--font-mono);font-size:.6rem;letter-spacing:.16em;text-transform:uppercase;color:var(--white-30);margin-bottom:12px}
.stat-box-value{font-family:var(--font-disp);font-size:1.6rem;font-weight:700;color:var(--white)}
.bar-group{display:flex;flex-direction:column;gap:12px}
.bar-item{display:grid;grid-template-columns:52px 1fr 36px;align-items:center;gap:12px}
.bar-label{font-size:.75rem;color:var(--white-60)}
.bar-track{height:4px;background:rgba(255,255,255,.07);border-radius:100px;overflow:hidden}
.bar-fill{height:100%;border-radius:100px;transition:width 1.2s var(--ease-out)}
.bar-female{background:linear-gradient(90deg,#C47A7A,#D4A0A0)}
.bar-male{background:linear-gradient(90deg,#6B8FAE,#8BAEC8)}
.bar-age{background:linear-gradient(90deg,var(--amber),var(--amber-hi))}
.bar-pct{font-family:var(--font-mono);font-size:.65rem;color:var(--white-30);text-align:right}
.lp-footer{background:var(--bg);border-top:1px solid var(--border);padding:64px 40px}
.footer-inner{max-width:var(--max-w);margin:0 auto;display:grid;grid-template-columns:1fr auto;gap:40px;align-items:end}
.footer-name{font-family:var(--font-disp);font-size:1.6rem;font-weight:700;color:var(--white);margin-bottom:8px}
.footer-address{font-size:.8rem;color:var(--white-30);line-height:1.7}
.footer-copy{font-family:var(--font-mono);font-size:.6rem;letter-spacing:.1em;color:var(--white-30);text-align:right}
.footer-hp-link{display:block;margin-top:6px;font-family:var(--font-mono);font-size:.62rem;color:var(--amber);letter-spacing:.06em}
.btn-primary{display:inline-flex;align-items:center;gap:10px;padding:14px 32px;background:var(--amber);color:var(--bg);border-radius:2px;font-family:var(--font-mono);font-size:.68rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;transition:background .2s,transform .2s}
.btn-primary:hover{background:var(--amber-hi);color:var(--bg);transform:translateY(-2px)}
.btn-outline{display:inline-flex;align-items:center;gap:10px;padding:13px 30px;background:transparent;color:var(--white-60);border:1px solid var(--border-hi);border-radius:2px;font-family:var(--font-mono);font-size:.68rem;letter-spacing:.14em;text-transform:uppercase;transition:all .2s}
.btn-outline:hover{border-color:var(--white-60);color:var(--white)}
.cta-strip{background:var(--amber);padding:64px 40px}
.cta-strip-inner{max-width:var(--max-w);margin:0 auto;display:flex;align-items:center;justify-content:space-between;gap:40px;flex-wrap:wrap}
.cta-strip-text{font-family:var(--font-disp);font-size:clamp(1.4rem,3vw,2.2rem);font-weight:700;color:var(--bg);line-height:1.2}
.cta-strip-text span{display:block;font-family:var(--font-mono);font-size:.65rem;font-weight:400;letter-spacing:.16em;text-transform:uppercase;color:rgba(13,13,13,.55);margin-bottom:6px}
.btn-cta-dark{display:inline-flex;align-items:center;gap:10px;padding:16px 36px;background:var(--bg);color:var(--amber);border-radius:2px;font-family:var(--font-mono);font-size:.7rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;white-space:nowrap;transition:transform .2s}
.btn-cta-dark:hover{transform:translateY(-2px);color:var(--amber-hi)}
@media(max-width:900px){.hero{grid-template-columns:1fr;gap:48px;min-height:auto;padding:60px 24px}.hero-right{display:none}.intro-grid{grid-template-columns:1fr;gap:40px}.access-layout{grid-template-columns:1fr;gap:48px}.atmosphere-grid{grid-template-columns:1fr}.atmo-card:first-child{grid-column:auto}.footer-inner{grid-template-columns:1fr}.footer-copy{text-align:left}}
@media(max-width:720px){:root{--nav-h:56px}.lp-section,.lp-section-full{padding:80px 24px}.nav-links{display:none}.nav-hamburger{display:flex}.section-title{font-size:2rem}.cta-strip-inner{flex-direction:column;align-items:flex-start}.message-block{padding:40px 28px}.coupons-grid{grid-template-columns:1fr}.staff-grid{grid-template-columns:1fr}.stats-row{grid-template-columns:1fr 1fr}}
`;

// ============================================================
// 共通JS (インライン用)
// ============================================================
const COMMON_JS = `
function esc(s){if(!s&&s!==0)return'';return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')}
function initReveal(){const o=new IntersectionObserver(e=>{e.forEach(el=>{if(el.isIntersecting){el.target.classList.add('visible');o.unobserve(el.target)}})},{threshold:0.06});document.querySelectorAll('.reveal').forEach(el=>o.observe(el))}
function buildNav(salon,currentFile){
  const PAGES=[{href:'index.html',label:'Top'},{href:'coupon.html',label:'Coupon'},{href:'staff.html',label:'Staff'},{href:'atmosphere.html',label:'Atmosphere'},{href:'access.html',label:'Access'}];
  const links=PAGES.map(p=>{const active=currentFile===p.href?' class="active"':'';return '<li><a href="'+p.href+'"'+active+'>'+p.label+'</a></li>'}).join('');
  const nav=document.createElement('nav');nav.className='lp-nav';
  nav.innerHTML='<div class="nav-logo">'+esc(salon.name||'')+'</div><ul class="nav-links">'+links+'</ul><a href="index.html#reserve" class="nav-reserve">予約する</a><button class="nav-hamburger" id="nav-hb" aria-label="menu"><span></span><span></span><span></span></button>';
  document.body.prepend(nav);
  const drawer=document.createElement('div');drawer.className='nav-drawer';drawer.id='nav-drawer';
  drawer.innerHTML=PAGES.map(p=>'<a href="'+p.href+'">'+p.label+'</a>').join('')+'<a href="index.html#reserve" style="color:var(--amber)">予約する</a>';
  document.body.appendChild(drawer);
  document.getElementById('nav-hb').addEventListener('click',()=>drawer.classList.toggle('open'));
  drawer.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>drawer.classList.remove('open')));
}
function buildFooter(salon){
  const f=document.createElement('footer');f.className='lp-footer';
  f.innerHTML='<div class="footer-inner"><div><div class="footer-name">'+esc(salon.name||'')+'</div><div class="footer-address">'+(salon.address?esc(salon.address):'')+(salon.openingHours?'<br>'+esc(salon.openingHours):'')+'</div></div><div class="footer-copy">'+(salon.homepageUrl?'<a class="footer-hp-link" href="'+esc(salon.homepageUrl)+'" target="_blank" rel="noopener">'+esc(salon.homepageUrl)+'</a>':'')+'</div></div>';
  document.body.appendChild(f);
}
function buildCTAStrip(salon){
  const s=document.createElement('div');s.className='cta-strip';
  s.innerHTML='<div class="cta-strip-inner"><div class="cta-strip-text"><span>Reserve</span>'+esc(salon.name||'')+'へのご予約はこちら</div><a href="index.html#reserve" class="btn-cta-dark">今すぐ予約する →</a></div>';
  return s;
}
function initBarAnimate(){const o=new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting){entry.target.querySelectorAll('.bar-fill[data-target]').forEach(b=>{setTimeout(()=>{b.style.width=b.dataset.target+'%'},150)});o.unobserve(entry.target)}})},{threshold:0.2});document.querySelectorAll('.stat-box').forEach(b=>o.observe(b))}
function buildStars(rating){let html='';const full=Math.floor(rating),half=rating%1>=0.3;for(let i=0;i<5;i++){if(i<full)html+='<span class="hero-star">★</span>';else if(i===full&&half)html+='<span class="hero-star" style="opacity:.5">★</span>';else html+='<span class="hero-star" style="opacity:.15">★</span>'}return html}
function getInitials(name){if(!name)return'?';if(/[\u3040-\u30FF\u4E00-\u9FFF]/.test(name))return name.charAt(0);return name.split(/\s+/).map(w=>w.charAt(0)).join('').toUpperCase().substring(0,2)}
function statRow(label,value){if(!value)return'';return'<div class="intro-stat-row"><span class="intro-stat-label">'+esc(label)+'</span><span class="intro-stat-value">'+esc(value)+'</span></div>'}
`;

// ============================================================
// ページ HTML 生成
// ============================================================

function wrap(title, bodyContent, salonName) {
  return `<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<title>${esc(title)}${salonName ? ' | ' + esc(salonName) : ''}</title>
<style>${COMMON_CSS}</style>
</head>
<body>
<div class="lp-page" id="lp-page"></div>
<script>
${COMMON_JS}
(function(){
const salon = ${/* データはここに埋め込まれる */'__SALON_JSON__'};
${bodyContent}
})();
<\/script>
</body>
</html>`;
}

// ── TOP ──
function genTop(salon) {
  const body = `
buildNav(salon,'index.html');
const page=document.getElementById('lp-page');

// Hero
page.insertAdjacentHTML('beforeend',\`
<section class="hero">
  <div class="hero-left">
    \${salon.heroCatch?'<div class="hero-badge">'+esc(salon.heroCatch)+'</div>':''}
    <h1 class="hero-name reveal">\${esc(salon.name)}</h1>
    \${salon.title?'<p class="hero-title reveal reveal-delay-1">'+esc(salon.title)+'</p>':''}
    \${(salon.rating||salon.reviewCount)?'<div class="hero-rating-row reveal reveal-delay-2">'+(salon.rating?'<div class="hero-score">'+salon.rating+'</div>':'')+(salon.rating?'<div class="hero-stars">'+buildStars(salon.rating)+'</div>':'')+(salon.reviewCount?'<div class="hero-review-count">'+salon.reviewCount.toLocaleString()+' reviews</div>':'')+'</div>':''}
    <div class="hero-actions reveal reveal-delay-3">
      <a href="#reserve" class="btn-primary">予約する →</a>
      <a href="coupon.html" class="btn-outline">クーポンを見る</a>
    </div>
  </div>
  <div class="hero-right reveal reveal-delay-2">
    <div class="hero-card">
      \${(salon.heroCatch||salon.introText)?'<p class="hero-card-catch">'+esc((salon.heroCatch||salon.introText).substring(0,120))+'</p>':''}
      \${salon.accessShort?'<div class="hero-access"><span class="hero-access-icon">⊙</span><span>'+esc(salon.accessShort)+'</span></div>':''}
      <div class="hero-deco-num">01</div>
    </div>
  </div>
</section>\`);

// Intro + stats
const hasIntro=salon.introText;
const hasStats=salon.cutPrice||salon.seatCount||salon.staffCount||(salon.stats&&salon.stats.firstVisitPrice);
if(hasIntro||hasStats){
  page.insertAdjacentHTML('beforeend','<section class="lp-section"><div class="intro-grid">'+(hasIntro?'<div class="reveal"><div class="section-eyebrow"><span class="section-tag">About</span><span class="section-line"></span></div><h2 class="section-title">サロン<em>について</em></h2><p class="intro-text">'+esc(salon.introText)+'</p></div>':'<div></div>')+(hasStats?'<div class="reveal reveal-delay-2"><div class="intro-stats">'+statRow('カット価格',(salon.cutPrice||'')+(salon.cutPrice?'〜':''))+statRow('席数',salon.seatCount)+statRow('スタッフ',salon.staffCount)+statRow('初来店 平均',salon.stats&&salon.stats.firstVisitPrice)+statRow('2回目以降 平均',salon.stats&&salon.stats.repeatVisitPrice)+statRow('営業時間',salon.openingHours)+statRow('定休日',salon.closedDays)+'</div></div>':'')+'</div></section>');
}

// Divider
page.insertAdjacentHTML('beforeend','<hr class="lp-divider"/>');

// Features
if(salon.features&&salon.features.length>0){
  let featHtml='<section class="lp-section"><div class="section-eyebrow reveal"><span class="section-tag">Features</span><span class="section-line"></span></div><h2 class="section-title reveal reveal-delay-1">サロンの<em>こだわり</em></h2><div class="features-list">';
  salon.features.forEach((f,i)=>{featHtml+='<div class="feature-item reveal" style="transition-delay:'+(i*0.06)+'s"><div class="feature-num-col"><span class="feature-num">0'+(i+1)+'</span></div><div class="feature-content-col"><h3 class="feature-title">'+esc(f.title)+'</h3><p class="feature-text">'+esc(f.text)+'</p></div></div>'});
  featHtml+='</div></section>';
  page.insertAdjacentHTML('beforeend',featHtml);
}

// CTA
const reserve=document.createElement('div');reserve.id='reserve';reserve.appendChild(buildCTAStrip(salon));page.appendChild(reserve);
buildFooter(salon);
initReveal();
`;
  return wrap('Top', body, salon.name).replace("'__SALON_JSON__'", JSON.stringify(JSON.stringify(salon)));
}

// ── COUPON ──
function genCoupon(salon) {
  const body = `
buildNav(salon,'coupon.html');
const page=document.getElementById('lp-page');
page.insertAdjacentHTML('beforeend','<section class="lp-section" style="padding-bottom:0"><div class="section-eyebrow reveal"><span class="section-tag">Coupon</span><span class="section-line"></span></div><h1 class="section-title reveal reveal-delay-1">人気<em>クーポン</em></h1>'+(salon.coupons&&salon.coupons.length?'<p class="section-lead reveal reveal-delay-2">'+salon.coupons.length+'件のクーポンをご用意しています。</p>':'')+'</section>');
if(!salon.coupons||!salon.coupons.length){
  page.insertAdjacentHTML('beforeend','<section class="lp-section"><p style="font-family:var(--font-mono);font-size:.8rem;color:var(--white-30);letter-spacing:.1em">クーポン情報がありません</p></section>');
}else{
  const types=['すべて',...new Set(salon.coupons.map(c=>c.type))];
  let filtersHtml='<div class="coupon-filters reveal">'+types.map(t=>'<button class="filter-btn'+(t==='すべて'?' active':'')+'" data-filter="'+esc(t)+'">'+esc(t)+'</button>').join('')+'</div>';
  let gridHtml='<div class="coupons-grid" id="cgrid">';
  salon.coupons.forEach((c,i)=>{
    const cats=(c.categories||[]).join(' · ');
    gridHtml+='<div class="coupon-card reveal" style="transition-delay:'+(i%3*0.07)+'s" data-type="'+esc(c.type)+'"><div class="coupon-type-badge">'+esc(c.type)+'</div>'+(cats?'<div class="coupon-cats">'+esc(cats)+'</div>':'')+'<div class="coupon-price"><span>¥</span>'+(c.price?c.price.toLocaleString():'–')+'</div><p class="coupon-title">'+esc(c.title)+'</p></div>';
  });
  gridHtml+='<div id="cempty" style="display:none;grid-column:1/-1;padding:80px 40px;text-align:center;font-family:var(--font-mono);font-size:.75rem;color:var(--white-30)">該当クーポンなし</div></div>';
  page.insertAdjacentHTML('beforeend','<section class="lp-section" style="padding-top:40px">'+filtersHtml+gridHtml+'</section>');
  document.querySelector('.coupon-filters').addEventListener('click',e=>{
    const btn=e.target.closest('.filter-btn');if(!btn)return;
    document.querySelectorAll('.filter-btn').forEach(b=>b.classList.remove('active'));btn.classList.add('active');
    const f=btn.dataset.filter;let vis=0;
    document.querySelectorAll('.coupon-card').forEach(card=>{const show=f==='すべて'||card.dataset.type===f;card.dataset.hidden=show?'false':'true';if(show)vis++});
    document.getElementById('cempty').style.display=vis===0?'block':'none';
  });
}
if(salon.stats&&(salon.stats.firstVisitPrice||salon.stats.repeatVisitPrice)){
  page.insertAdjacentHTML('beforeend','<section class="lp-section" style="padding-top:0"><hr class="lp-divider" style="margin-bottom:60px"/><div class="section-eyebrow reveal"><span class="section-tag">Price Guide</span><span class="section-line"></span></div><h2 class="section-title reveal reveal-delay-1">平均<em>予約金額</em></h2><div class="stats-row" style="margin-top:40px">'+(salon.stats.firstVisitPrice?'<div class="stat-box reveal"><div class="stat-box-label">初来店</div><div class="stat-box-value">'+esc(salon.stats.firstVisitPrice)+'</div></div>':'')+(salon.stats.repeatVisitPrice?'<div class="stat-box reveal reveal-delay-1"><div class="stat-box-label">2回目以降</div><div class="stat-box-value">'+esc(salon.stats.repeatVisitPrice)+'</div></div>':'')+'</div></section>');
}
page.appendChild(buildCTAStrip(salon));buildFooter(salon);initReveal();
`;
  return wrap('クーポン', body, salon.name).replace("'__SALON_JSON__'", JSON.stringify(JSON.stringify(salon)));
}

// ── STAFF ──
function genStaff(salon) {
  const body = `
buildNav(salon,'staff.html');
const page=document.getElementById('lp-page');
page.insertAdjacentHTML('beforeend','<section class="lp-section" style="padding-bottom:0"><div class="section-eyebrow reveal"><span class="section-tag">Staff</span><span class="section-line"></span></div><h1 class="section-title reveal reveal-delay-1"><em>スタイリスト</em>紹介</h1></section>');
if(!salon.staff||!salon.staff.length){
  page.insertAdjacentHTML('beforeend','<section class="lp-section"><p style="font-family:var(--font-mono);font-size:.8rem;color:var(--white-30)">スタッフ情報がありません</p></section>');
}else{
  let gridHtml='<section class="lp-section" style="padding-top:48px"><div class="staff-grid">';
  salon.staff.forEach((s,i)=>{
    gridHtml+='<div class="staff-card reveal" style="transition-delay:'+(i*0.08)+'s" data-index="0'+(i+1)+'"><div class="staff-avatar">'+esc(getInitials(s.name))+'</div><h2 class="staff-name">'+esc(s.name)+'</h2>'+(s.experience?'<span class="staff-exp">'+esc(s.experience)+'</span>':'')+(s.specialty?'<p class="staff-specialty">'+esc(s.specialty)+'</p>':'')+(s.catch?'<p class="staff-catch">'+esc(s.catch)+'</p>':'')+'</div>';
  });
  gridHtml+='</div></section>';
  page.insertAdjacentHTML('beforeend',gridHtml);
}
if(salon.coupons&&salon.coupons.length){page.insertAdjacentHTML('beforeend','<section class="lp-section" style="padding-top:0;text-align:center"><a href="coupon.html" class="btn-outline">クーポンを見る →</a></section>')}
page.appendChild(buildCTAStrip(salon));buildFooter(salon);initReveal();
`;
  return wrap('スタッフ', body, salon.name).replace("'__SALON_JSON__'", JSON.stringify(JSON.stringify(salon)));
}

// ── ATMOSPHERE ──
function genAtmosphere(salon) {
  const body = `
buildNav(salon,'atmosphere.html');
const page=document.getElementById('lp-page');
page.insertAdjacentHTML('beforeend','<section class="lp-section" style="padding-bottom:0"><div class="section-eyebrow reveal"><span class="section-tag">Atmosphere</span><span class="section-line"></span></div><h1 class="section-title reveal reveal-delay-1">サロンの<em>雰囲気</em></h1></section>');
if(salon.atmosphere&&salon.atmosphere.length){
  let gridHtml='<div style="max-width:var(--max-w);margin:0 auto;padding:0 40px"><div class="atmosphere-grid">';
  salon.atmosphere.forEach((a,i)=>{gridHtml+='<div class="atmo-card reveal" style="transition-delay:'+(i*0.07)+'s"><div class="atmo-deco"></div><div class="atmo-index">'+String(i+1).padStart(2,'0')+'</div><p class="atmo-text">'+esc(a)+'</p></div>'});
  gridHtml+='</div></div>';
  page.insertAdjacentHTML('beforeend',gridHtml);
}
if(salon.messageText){
  page.insertAdjacentHTML('beforeend','<section class="lp-section"><div class="section-eyebrow reveal"><span class="section-tag">Message</span><span class="section-line"></span></div><h2 class="section-title reveal reveal-delay-1">'+(salon.messageTitle?esc(salon.messageTitle):'サロンからの<em>一言</em>')+'</h2><div class="message-block reveal reveal-delay-2"><p class="message-text">'+esc(salon.messageText)+'</p><p class="message-author">— '+esc(salon.name)+'</p></div></section>');
}
page.appendChild(buildCTAStrip(salon));buildFooter(salon);initReveal();
`;
  return wrap('雰囲気', body, salon.name).replace("'__SALON_JSON__'", JSON.stringify(JSON.stringify(salon)));
}

// ── ACCESS ──
function genAccess(salon) {
  const body = `
buildNav(salon,'access.html');
const page=document.getElementById('lp-page');
page.insertAdjacentHTML('beforeend','<section class="lp-section" style="padding-bottom:0"><div class="section-eyebrow reveal"><span class="section-tag">Access</span><span class="section-line"></span></div><h1 class="section-title reveal reveal-delay-1">アクセス・<em>店舗情報</em></h1></section>');
const rows=[['営業時間',salon.openingHours],['定休日',salon.closedDays],['支払い方法',salon.paymentMethods],['席数',salon.seatCount],['スタッフ',salon.staffCount],['駐車場',salon.parking],['カット価格',salon.cutPrice]].filter(([,v])=>v&&String(v).trim());
const tableHtml=rows.length?'<div class="reveal reveal-delay-1"><div class="access-table-wrap">'+rows.map(([k,v])=>'<div class="access-row"><div class="access-row-key">'+esc(k)+'</div><div class="access-row-val">'+esc(v)+'</div></div>').join('')+'</div></div>':'';
const leftHtml='<div class="reveal">'+(salon.address?'<div class="access-address-block"><div class="access-address-label">Address</div><div class="access-address-text">'+esc(salon.address)+'</div></div>':'')+(salon.accessFull||salon.accessShort?'<div class="access-route">'+esc(salon.accessFull||salon.accessShort)+'</div>':'')+(salon.homepageUrl?'<div class="access-homepage"><a href="'+esc(salon.homepageUrl)+'" target="_blank" rel="noopener">'+esc(salon.homepageUrl)+'</a></div>':'')+'</div>';
page.insertAdjacentHTML('beforeend','<section class="lp-section" style="padding-top:48px"><div class="access-layout">'+leftHtml+tableHtml+'</div></section>');
const s=salon.stats||{};
const hasG=s.genderRatio&&s.genderRatio.female!==null&&s.genderRatio.female!==undefined;
const hasA=s.ageRatio&&s.ageRatio.length;
if(s.firstVisitPrice||s.repeatVisitPrice||hasG||hasA){
  let statsHtml='<section class="lp-section"><hr class="lp-divider" style="margin-bottom:60px"/><div class="section-eyebrow reveal"><span class="section-tag">Data</span><span class="section-line"></span></div><h2 class="section-title reveal reveal-delay-1">利用<em>傾向</em></h2><div class="stats-row reveal reveal-delay-2">';
  if(s.firstVisitPrice)statsHtml+='<div class="stat-box"><div class="stat-box-label">初来店 平均</div><div class="stat-box-value">'+esc(s.firstVisitPrice)+'</div></div>';
  if(s.repeatVisitPrice)statsHtml+='<div class="stat-box"><div class="stat-box-label">2回目以降 平均</div><div class="stat-box-value">'+esc(s.repeatVisitPrice)+'</div></div>';
  if(hasG){statsHtml+='<div class="stat-box"><div class="stat-box-label">性別比率</div><div class="bar-group" style="margin-top:12px">'+(s.genderRatio.female!==null?'<div class="bar-item"><span class="bar-label">女性</span><div class="bar-track"><div class="bar-fill bar-female" style="width:0" data-target="'+s.genderRatio.female+'"></div></div><span class="bar-pct">'+s.genderRatio.female+'%</span></div>':'')+(s.genderRatio.male!==null?'<div class="bar-item"><span class="bar-label">男性</span><div class="bar-track"><div class="bar-fill bar-male" style="width:0" data-target="'+s.genderRatio.male+'"></div></div><span class="bar-pct">'+s.genderRatio.male+'%</span></div>':'')+'</div></div>'}
  if(hasA){statsHtml+='<div class="stat-box"><div class="stat-box-label">年代比率</div><div class="bar-group" style="margin-top:12px">'+s.ageRatio.map(a=>'<div class="bar-item"><span class="bar-label">'+esc(a.label)+'</span><div class="bar-track"><div class="bar-fill bar-age" style="width:0" data-target="'+a.value+'"></div></div><span class="bar-pct">'+a.value+'%</span></div>').join('')+'</div></div>'}
  statsHtml+='</div></section>';
  page.insertAdjacentHTML('beforeend',statsHtml);
  initBarAnimate();
}
page.appendChild(buildCTAStrip(salon));buildFooter(salon);initReveal();
`;
  return wrap('アクセス', body, salon.name).replace("'__SALON_JSON__'", JSON.stringify(JSON.stringify(salon)));
}

// ============================================================
// ZIP 生成 & ダウンロード
// ============================================================

export async function exportSiteAsZip(salon) {
  if (typeof JSZip === 'undefined') {
    throw new Error('JSZip が読み込まれていません');
  }

  const zip = new JSZip();
  const folder = zip.folder(sanitizeFolderName(salon.name) || 'salon-site');

  folder.file('index.html',       genTop(salon));
  folder.file('coupon.html',      genCoupon(salon));
  folder.file('staff.html',       genStaff(salon));
  folder.file('atmosphere.html',  genAtmosphere(salon));
  folder.file('access.html',      genAccess(salon));

  const blob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = (sanitizeFolderName(salon.name) || 'salon-site') + '.zip';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function esc(s) {
  if (!s && s !== 0) return '';
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function sanitizeFolderName(name) {
  if (!name) return '';
  return name.replace(/[^\w\u3040-\u30FF\u4E00-\u9FFF\u3400-\u4DBF\-]/g, '_').substring(0, 40);
}
